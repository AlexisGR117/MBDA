-- CICLO 1: Tablas

CREATE TABLE users(
    id              NUMBER(5) NOT NULL, 
	email           VARCHAR2(100) NOT NULL,
	name            VARCHAR2(50) NOT NULL,
	createdAT       DATE NOT NULL);
CREATE TABLE accounts(
    id              NUMBER(5) NOT NULL,
    users_id	    NUMBER(5) NOT NULL,
    name            VARCHAR2(70) NOT NULL,
    createdAt       DATE NOT NULL,
    subscribers     NUMBER(5) NOT NULL);
CREATE TABLE exclusiveness(
    code            VARCHAR2(9) NOT NULL,
    accounts_id	    NUMBER(5) NOT NULL,
    orden           NUMBER(3) NOT NULL,
    name            VARCHAR2(55) NOT NULL,
    price           NUMBER(9),
    duration        NUMBER(2));
CREATE TABLE subscriptions(
    id		        NUMBER(5) NOT NULL,
    accounts_id	    NUMBER(5) NOT NULL,
    subscribed_to   NUMBER(5) NOT NULL,
    createdAt       DATE NOT NULL,
    detail	        VARCHAR2(50));
CREATE TABLE contents(
    id                  NUMBER(10) NOT NULL,
    users_id            NUMBER(5) NOT NULL,
    exclusiveness_code  VARCHAR2(9),
    title               VARCHAR2(20) NOT NULL,
    publishingDate      DATE NOT NULL,
    description         VARCHAR2(30));
CREATE TABLE stages(
    exclusiveness_code  VARCHAR2(9) NOT NULL,
    subscriptions_id    NUMBER(5) NOT NULL,
    startAT             DATE NOT NULL,
    endAT               DATE,
    price               NUMBER(9) NOT NULL,
    status              VARCHAR2(9) NOT NULL);
CREATE TABLE lables(
    exclusiveness_code	VARCHAR2(9) NOT NULL,
    lable         	    VARCHAR2(10) NOT NULL);
CREATE TABLE likes(
    users_id	        NUMBER(5) NOT NULL,
    contents_id         NUMBER(10) NOT NULL);
CREATE TABLE videos(
    contents_id         NUMBER(10) NOT NULL,
    duration            NUMBER(4) NOT NULL);
CREATE TABLE events(
    contents_id         NUMBER(10) NOT NULL,
    plannedDate         DATE,
    duration            NUMBER(4));
CREATE TABLE posts(
    contents_id         NUMBER(10) NOT NULL,
    text                VARCHAR2(50) NOT NULL);

CREATE TRIGGER suscripciones
AFTER INSERT ON subscriptions
FOR EACH ROW
BEGIN
    UPDATE accounts SET subscribers = subscribers + 1
    WHERE accounts.id = :NEW.subscribed_to;
END;

-- CICLO 1: Atributos

ALTER TABLE stages ADD CONSTRAINT CK_stage_status
    CHECK (status IN ('Active', 'Finished', 'Cancelled'));
ALTER TABLE exclusiveness ADD CONSTRAINT CK_exclusiveness_code
    CHECK (REGEXP_LIKE(code, '^EX-\d{6}'));
ALTER TABLE lables ADD CONSTRAINT CK_lables_lable
    CHECK (lable LIKE '#%');
ALTER TABLE exclusiveness ADD CONSTRAINT CK_exclusiveness_duration
    CHECK (duration between 1 AND 90);
ALTER TABLE users ADD CONSTRAINT CK_users_email
    CHECK (email LIKE '%@%.%');
ALTER TABLE videos ADD CONSTRAINT CK_videos_duration
    CHECK (duration between 1 AND 1380);
ALTER TABLE events ADD CONSTRAINT CK_events_duration
    CHECK (duration between 1 AND 1380);  
ALTER TABLE exclusiveness ADD CONSTRAINT CK_exclusiveness_price
    CHECK (price >= 0);
ALTER TABLE stages ADD CONSTRAINT CK_stages_price
    CHECK (price >= 0);
ALTER TABLE exclusiveness ADD CONSTRAINT CK_exclusiveness_orden
    CHECK (orden >= 0);
-- Nuevas condiciones de integridad sobre los atributos
-- El precio del nivel de exclusividad y de etapa deben ser a lo sumo 500000000
ALTER TABLE exclusiveness ADD CONSTRAINT CK_exclusiveness_price_2
    CHECK (price <= 500000000);
ALTER TABLE stages ADD CONSTRAINT CK_stages_price_2
    CHECK (price <= 500000000);
-- El nombre del usuario debe tener al menos un espacio     
ALTER TABLE users ADD CONSTRAINT CK_users_name
    CHECK (name LIKE '% %');    

-- CICLO 1: Primarias

ALTER TABLE users ADD CONSTRAINT PK_users
    PRIMARY KEY (id);
ALTER TABLE accounts ADD CONSTRAINT PK_accounts
    PRIMARY KEY (id);
ALTER TABLE exclusiveness ADD CONSTRAINT PK_exclusiveness
    PRIMARY KEY (code);
ALTER TABLE subscriptions ADD CONSTRAINT PK_subscriptions
    PRIMARY KEY (id);
ALTER TABLE contents ADD  CONSTRAINT PK_contents
    PRIMARY KEY (id);
ALTER TABLE stages ADD CONSTRAINT PK_stages
    PRIMARY KEY (exclusiveness_code, subscriptions_id);
ALTER TABLE lables ADD CONSTRAINT PK_lables
    PRIMARY KEY (exclusiveness_code, lable);
ALTER TABLE likes ADD CONSTRAINT PK_likes
    PRIMARY KEY (users_id, contents_id);
ALTER TABLE videos ADD CONSTRAINT PK_videos
    PRIMARY KEY (contents_id);
ALTER TABLE events ADD CONSTRAINT PK_events
    PRIMARY KEY (contents_id);
ALTER TABLE posts ADD CONSTRAINT PK_posts
    PRIMARY KEY (contents_id);

-- CICLO 1: Unicas

ALTER TABLE users ADD CONSTRAINT UK_users_email
    UNIQUE (email);

-- CICLO 1: Foraneas

ALTER TABLE accounts ADD CONSTRAINT FK_accounts_users
    FOREIGN KEY (users_id) REFERENCES users(id);
ALTER TABLE exclusiveness ADD CONSTRAINT FK_exclusiveness_accounts
    FOREIGN KEY (accounts_id) REFERENCES accounts(id);
ALTER TABLE subscriptions ADD CONSTRAINT FK_subscriptions_accounts
    FOREIGN KEY (accounts_id) REFERENCES accounts(id);
ALTER TABLE subscriptions ADD CONSTRAINT FK_subscriptions_subscribed_to
    FOREIGN KEY (subscribed_to) REFERENCES accounts(id);
ALTER TABLE contents ADD CONSTRAINT FK_contents_users
    FOREIGN KEY (users_id) REFERENCES users(id);
ALTER TABLE contents ADD CONSTRAINT FK_contents_exclusiveness
    FOREIGN KEY (exclusiveness_code) REFERENCES exclusiveness(code);
ALTER TABLE stages ADD CONSTRAINT FK_stages_exclusiveness
    FOREIGN KEY (exclusiveness_code) REFERENCES exclusiveness(code);
ALTER TABLE lables ADD CONSTRAINT FK_lables_exclusiveness
    FOREIGN KEY (exclusiveness_code) REFERENCES exclusiveness(code);
ALTER TABLE likes ADD CONSTRAINT FK_likes_contents
    FOREIGN KEY (contents_id) REFERENCES contents(id);
ALTER TABLE videos ADD CONSTRAINT FK_videos_contents
    FOREIGN KEY (contents_id) REFERENCES contents(id);
ALTER TABLE events ADD CONSTRAINT FK_events_contents
    FOREIGN KEY (contents_id) REFERENCES contents(id);
ALTER TABLE posts ADD CONSTRAINT FK_posts_contents
    FOREIGN KEY (contents_id) REFERENCES contents(id);
    
-- CICLO 1: PoblarOK

INSERT INTO users
    VALUES(1, 'user_name_1@gmail.com', 'user name 1', '01/01/2000');
INSERT INTO users
    VALUES(2, 'user_name_2@gmail.com', 'user name 2', '02/02/2001');
INSERT INTO users
    VALUES(3, 'user_name_3@gmail.com', 'user name 3', '03/03/2002');

INSERT INTO accounts
    VALUES(1, 2, 'account_name_1', '04/04/2010', 0);
INSERT INTO accounts
    VALUES(2, 2, 'account_name_2', '05/05/2011', 0);
INSERT INTO accounts
    VALUES(3, 1, 'account_name_3', '06/06/2012', 0);

INSERT INTO subscriptions
    VALUES(1, 1, 2, '07/07/2020', 'subscription_detail_1');
INSERT INTO subscriptions
    VALUES(2, 2, 2, '08/08/2021', 'subscription_detail_2');
INSERT INTO subscriptions
    VALUES(3, 3, 1, '09/09/2022', NULL);

INSERT INTO exclusiveness
    VALUES('EX-100001', 1, 0, 'Free', 0, 30);
INSERT INTO exclusiveness
    VALUES('EX-100002', 2, 1, 'Free', NULL, 20);
INSERT INTO exclusiveness
    VALUES('EX-100003', 3, 2, 'Premium', 300, NULL);

INSERT INTO contents
    VALUES(1, 1, 'EX-100001', 'content_title_1', '10/10/2020',
           'content_description_1');
INSERT INTO contents
    VALUES(2, 2, NULL, 'content_title_2', '11/11/2021', NULL);
INSERT INTO contents
    VALUES(3, 1, 'EX-100003', 'content_title_3', '12/12/2022',
           'content_description_3');
INSERT INTO contents
    VALUES(4, 2, 'EX-100002', 'content_title_4', '01/01/2022',
           'content_description_4');
INSERT INTO contents
    VALUES(5, 2, 'EX-100002', 'content_title_5', '02/01/2022',
           'content_description_5');
INSERT INTO contents
    VALUES(6, 1, 'EX-100003', 'content_title_6', '03/01/2022',
           'content_description_6');
INSERT INTO contents
    VALUES(7, 2, 'EX-100001', 'content_title_7', '04/01/2022',
           'content_description_7');
INSERT INTO contents
    VALUES(8, 1, NULL, 'content_title_8', '05/01/2022', NULL);
INSERT INTO contents
    VALUES(9, 2, 'EX-100001', 'content_title_9', '05/01/2022',
           'content_description_9');

INSERT INTO stages
    VALUES('EX-100001', 1, '10/10/2020', '11/11/2021', 100, 'Finished');
INSERT INTO stages
    VALUES('EX-100002', 2, '11/11/2021', '12/12/2022', 300, 'Active');
INSERT INTO stages
    VALUES('EX-100003', 3, '12/12/2022', NULL, 300, 'Active');

INSERT INTO lables
    VALUES('EX-100001', '#abc_123');
INSERT INTO lables
    VALUES('EX-100001', '#defg_45');
INSERT INTO lables
    VALUES('EX-100002', '#h6i_jk7');

INSERT INTO likes
    VALUES(1, 1);
INSERT INTO likes
    VALUES(1, 2);
INSERT INTO likes
    VALUES(3, 1);

INSERT INTO videos
    VALUES(1, 20);
INSERT INTO videos
    VALUES(2, 15);
INSERT INTO videos
    VALUES(3, 35);

INSERT INTO events
    VALUES(4, '01/01/2015', NULL);
INSERT INTO events
    VALUES(5, '02/03/2016', 60);
INSERT INTO events
    VALUES(6, NULL, 70);

INSERT INTO posts
    VALUES(7, 'post_text_1');
INSERT INTO posts
    VALUES(8, 'post_text_2');
INSERT INTO posts
    VALUES(9, 'post_text_3');
    
-- Nuevamente poblando

insert into users (email, name) values ('mcollocott0@google.ca', 'Mick Collocott');
insert into users (email, name) values ('tgelling1@infoseek.co.jp', 'Tanitansy Gelling');
insert into users (email, name) values ('mcarroll2@ovh.net', 'Misti Carroll');
insert into users (email, name) values ('cmalmar3@google.com.hk', 'Chandler Malmar');
insert into users (email, name) values ('bchattey4@yelp.com', 'Buiron Chattey');

insert into accounts (id, users_id, name, createdAT, subscribers) values (69966, 13964, 'sgodson0', '09/07/2017', 0);
insert into accounts (id, users_id, name, createdAT, subscribers) values (99251, 26831, 'jpietruszka1', '24/07/2005', 0);
insert into accounts (id, users_id, name, createdAT, subscribers) values (2727, 99275, 'apietruszewicz2', '29/07/2018', 0);
insert into accounts (id, users_id, name, createdAT, subscribers) values (50573, 36430, 'gtournie3', '30/07/2015', 0);
insert into accounts (id, users_id, name, createdAT, subscribers) values (82238, 97946, 'agorrick4', '11/04/2009', 0);

insert into exclusiveness (code, accounts_id, orden, name, price, duration) values ('EX-134807', 69966, 386, 'Baykit', 373385314, 7);
insert into exclusiveness (code, accounts_id, orden, name, price, duration) values ('EX-317194', 99251, 353, 'Luso', NULL, 54);
insert into exclusiveness (code, accounts_id, orden, name, price, duration) values ('EX-838104', 2727, 589, 'Banyuurip', NULL, 57);
insert into exclusiveness (code, accounts_id, orden, name, price, duration) values ('EX-404179', 50573, 765, 'Haoxin', 423994699, NULL);
insert into exclusiveness (code, accounts_id, orden, name, price, duration) values ('EX-474975', 82238, 448, 'Kranggan', 178564016, 6);

insert into contents (id, users_id, exclusiveness_code, title, publishingDate, description) values (8695241034, 13964, 'EX-134807', 'eu est congue', '24/07/2016', 'nisi eu orci mauris lacinia');
insert into contents (id, users_id, exclusiveness_code, title, publishingDate, description) values (6746510175, 26831, 'EX-317194', 'vel augue', '24/10/2016', 'curabitur at ipsum ac tellus');
insert into contents (id, users_id, exclusiveness_code, title, publishingDate, description) values (8850155154, 99275, 'EX-838104', 'nisi', '01/01/2016', null);
insert into contents (id, users_id, exclusiveness_code, title, publishingDate, description) values (4133830149, 36430, 'EX-404179', 'sit', '23/04/2019', 'massa donec dapibus duis at');
insert into contents (id, users_id, exclusiveness_code, title, publishingDate, description) values (7101937512, 97946, 'EX-474975','vestibulum aliquet', '24/09/2013', 'mattis odio donec vitae');

insert into subscriptions (accounts_id, subscribed_to, detail) values (69966, 82238,'etiam vel augue vestibulum rutrum rutrum neque');
insert into subscriptions (accounts_id, subscribed_to, detail) values (99251, 82238,'natoque penatibus et magnis dis parturient');
insert into subscriptions (accounts_id, subscribed_to, detail) values (2727, 82238,'quisque ut erat curabitur gravida nisi');
insert into subscriptions (accounts_id, subscribed_to, detail) values (50573, 2727,'magna at nunc commodo');
insert into subscriptions accounts_id, subscribed_to, detail) values (82238, 99251,'eros vestibulum ac est lacinia nisi venenatis');

-- CICLO 1: PoblarNoOK

-- No deberian permitirse y no se permiten

-- Ingresar en el id del usuario una cadena cuando debe ser un numero
INSERT INTO users
    VALUES('uno', 'user_name_4@gmail.com', 'user_name_4', '11/11/2011');
-- Dejar en desconocido el id de la cuenta
INSERT INTO accounts
    VALUES(NULL, 7, 'account_name_4', '08/08/2008', 0);
-- Ingresar un id de 6 d�gitos del usuario
INSERT INTO users
    VALUES(123456, 'user_name_5@gmail.com', 'user_name_5', '28/05/2013');
-- Ingresar un numero en la fecha de creacion de la sucripcion
INSERT INTO subscriptions
    VALUES(4, 3, 1, 7, 'subscription_detail_4');
-- Tener como desconocido el id del usuario
INSERT INTO contents
    VALUES('content_id_4', NULL, NULL, 'content_title_8', '02/02/2020', NULL);
    
-- No deberin permitirse y todavia se permiten

-- Ingresar una clave foranea, en este caso el id de la suscrpcion,
-- que no esta en suscripcion.
-- Lo protege FK_stages_subscriptions
INSERT INTO stages
    VALUES('EX-100001', 5, '13/12/2020', '03/02/2021', 150, 'Active');
-- Repetir una clave primaria.
-- En lables esta se forma por el id del nivel de exclusividad y la etiqueta
-- Lo protege PK_lables
INSERT INTO lables
    VALUES('EX-100001', '#abc_123');
-- Repetir una clave unica en este caso el email.
-- Lo protege UK_users_email
INSERT INTO users
    VALUES(4, 'user_name_1@gmail.com', 'user name 4', '01/01/2000');
-- Poner un estado de una etapa diferente a 'Active', 'Finished' y 'Cancelled'
-- Lo protege CK_stage_status
INSERT INTO stages
    VALUES('EX-100009', 2, '27/07/2021', NULL, 270, 'Disabled');
-- Ingresar una cadena para el codigo del nivel de exlusividad que no sea de la
-- forma 'EX_N' donde N es un n�mero natural de 6 d�gitos.
-- Lo protege CK_exclusiveness_code
INSERT INTO exclusiveness
    VALUES('ex_4', 2, 1, 'Premium', 150, '35');

-- Otros cinco casos de proteccion de la base de datos

-- Un video con duracion mayor a 1380 minutos
-- Lo protege CK_videos_duration
INSERT INTO videos
    VALUES(3, '1400');
-- Poner una clave foranea a post que no esta en contenidos
-- Lo protege FK_posts_contents
INSERT INTO posts
    VALUES(10, 'post_text_4');
-- Ingresar un email sin @
-- Lo protege CK_users_email
INSERT INTO users
    VALUES(4, 'user_name_3_gmail.com', 'user name 4', '03/03/2002');
-- Insertar una clave primaria que ya estaba en eventos
-- Lo protege PK_events
INSERT INTO events
    VALUES(6, '10/03/2022', 45);
-- Un nivel de exclusividad mayor a 90 dias
-- Lo protege CK_exclusiveness_duration
INSERT INTO exclusiveness
    VALUES('EX-100004', 3, 2, 'Premium', 270, 95);

-- Protecci�n de la base de datos -nuevas restricciones 
-- Precio del nivel de exclusividad mayor a 500000000
INSERT INTO exclusiveness
    VALUES('EX-100004', 3, 2, 'Premium', 500000001, 95);
-- Nombre del usuario sin espacio
INSERT INTO users
    VALUES(4, 'user_name_4@gmail.com', 'user_name_4', TO_DATE('11/11/2011','DD/MM/YY'));
    
-- Consultar cuentas que tienen mas suscripciones

SELECT id, name, subscribers
  FROM accounts
   WHERE subscribers = (SELECT MAX(subscribers) FROM accounts);
   
-- Consultar la cantidad de contenidos publicados antes de 01/01/2022

SELECT COUNT(id) AS NoContenidos
  FROM contents
    WHERE publishingDate < '01/01/2022';
    
-- CICLO 1: CRUD: Mantener suscripcion 

--Atributos 

-- Acciones

ALTER TABLE stages ADD CONSTRAINT FK_stages_subscriptions
    FOREIGN KEY (subscriptions_id) REFERENCES subscriptions(id) ON DELETE CASCADE;

-- AccionesOk

DELETE FROM subscriptions WHERE id = 1;

--Disparadores

CREATE TRIGGER TR_SUSCRIPTION_BI
BEFORE INSERT ON subscriptions
FOR EACH ROW
DECLARE
    vacio NUMBER;
    mayor NUMBER;
    fecha DATE;
BEGIN
    SELECT COUNT(*) + 1 INTO vacio FROM subscriptions;
    IF vacio = 1 THEN 
        :NEW.id := vacio;
    ELSE 
        SELECT MAX(id) + 1 INTO mayor FROM subscriptions;
        :NEW.id := mayor;
    END IF;
    SELECT current_date INTO fecha FROM dual;
    :NEW.createdAt := fecha;
END;

CREATE TRIGGER TR_SUSCRIPTION_AI
AFTER INSERT ON subscriptions
FOR EACH ROW
DECLARE
    vacio NUMBER;
    fecha DATE;
    codigo VARCHAR2(9);
    existe NUMBER;
BEGIN
    SELECT current_date INTO fecha FROM dual;
    SELECT COUNT(*) INTO existe FROM exclusiveness WHERE orden = 0 AND accounts_id = :NEW.subscribed_to;
    IF existe = 0 THEN
        SELECT COUNT(*) INTO vacio FROM exclusiveness;
        IF vacio = 0 THEN
            codigo := 'EX-100001';
        ELSE
            SELECT CONCAT('EX-', TO_NUMBER(MAX(SUBSTR(code, 4, 9)))+1) INTO codigo FROM exclusiveness;
        END IF;
        INSERT INTO exclusiveness VALUES (codigo, :NEW.subscribed_to, 0, 'Free', NULL, NULL);
    ELSE
        SELECT code INTO codigo FROM exclusiveness WHERE orden = 0 AND accounts_id = :NEW.subscribed_to;
    END IF;
    INSERT INTO stages VALUES (codigo, :NEW.id, current_date, NULL, 0, 'Active');
END;

CREATE TRIGGER TR_SUSCRIPTION_BU
BEFORE UPDATE ON subscriptions
FOR EACH ROW
BEGIN
    :NEW.id  := :OLD.id;
    :NEW.accounts_id  := :OLD.accounts_id;
    :NEW.subscribed_to := :OLD.subscribed_to;
    :NEW.createdAt  := :OLD.createdAt;
END;

CREATE TRIGGER TR_SUSCRIPTION_BD
BEFORE DELETE ON subscriptions
FOR EACH ROW
DECLARE
    fecha DATE;
BEGIN
    SELECT current_date INTO fecha FROM dual;
    IF fecha - :OLD.createdAT > 2 THEN
        RAISE_APPLICATION_ERROR(-20001,
        'No se puede eliminar la suscripcion,
        solo se puede durante los primeros dos dias despues de creada');
    END IF;
END;

-- DisparadoresOK

INSERT INTO subscriptions (accounts_id, subscribed_to, detail)
    VALUES(1, 3, 'subscription_detail_1');
INSERT INTO subscriptions (accounts_id, subscribed_to, detail)
    VALUES(2, 1, 'subscription_detail_2');
INSERT INTO subscriptions (accounts_id, subscribed_to, detail)
    VALUES(3, 1, NULL);
UPDATE subscriptions SET detail = 'Detalle Prueba';
DELETE FROM subscriptions WHERE id = 1;

-- DisparadoresNoOk

-- Insertar el id y la fecha createdAT de una suscripcion,
-- esta se deber�a generar automaticamente 
INSERT INTO subscriptions
    VALUES(10, 1, 3, '17/01/2012', 'subscription_detail_1');
-- Actualizar datos que no son el detalle o la etapa, no se van a generar
-- cambios 
UPDATE subscriptions SET createdAt = '18/03/2020';
-- Eliminar una suscripci�n que no tenga mas de dos dias de creacion
DELETE FROM subscriptions WHERE id = 10;

-- XDisparadores

DROP TRIGGER TR_SUSCRIPTION_BI;
DROP TRIGGER TR_SUSCRIPTION_AI;
DROP TRIGGER TR_SUSCRIPTION_BU;
DROP TRIGGER TR_SUSCRIPTION_BD;

-- Consultas

SELECT accounts.id, accounts.name, EXTRACT(MONTH FROM startAT) AS Mes,
    EXTRACT(YEAR FROM startAT) AS A�o, COUNT(subscriptions.id) AS Suscripciones,
    SUM(price) AS Ganancias
    FROM subscriptions JOIN stages ON (subscriptions_id = subscriptions.id)
    JOIN accounts ON (subscribed_to = accounts.id)
    WHERE subscribed_to = 1
    GROUP BY EXTRACT(MONTH FROM startAT), EXTRACT(YEAR FROM startAT), 
             accounts.id, accounts.name;
    
-- CICLO 2: CRUD: Mantener usuario 

-- Acciones

ALTER TABLE likes ADD CONSTRAINT FK_likes_users
    FOREIGN KEY (users_id) REFERENCES users(id) ON DELETE CASCADE;
    
-- AccionesOK

DELETE FROM users WHERE id = 3;

-- Disparadores

CREATE TRIGGER TR_users_BI
BEFORE INSERT ON users
FOR EACH ROW
DECLARE
    vacio NUMBER;
    mayor NUMBER;
    fecha DATE;
    correos VARCHAR2(100);
    nombre VARCHAR2(70);
    nombreid VARCHAR2(75);
BEGIN
    SELECT COUNT(*) + 1 INTO vacio FROM users;
    IF vacio = 1 THEN 
        :NEW.id := vacio;
    ELSE 
        SELECT MAX(id) + 1 INTO mayor FROM users;
        :NEW.id := mayor;
    END IF;
    SELECT current_date INTO fecha FROM dual;
    :NEW.createdAt := fecha;
    IF :NEW.email IS NULL THEN
        SELECT CONCAT(REPLACE(:NEW.name, ' ', '_'), '_') INTO nombre FROM dual;
        SELECT CONCAT(nombre, :NEW.id) INTO nombreid FROM dual;
        SELECT CONCAT(nombreid, '@gmail.com') INTO correos FROM dual;
        :NEW.email := correos;
    END IF;
END;

CREATE TRIGGER TR_likes_BDU
BEFORE DELETE OR UPDATE ON likes
FOR EACH ROW
BEGIN
    RAISE_APPLICATION_ERROR(-20002,
    'No se puede actualizar o eliminar los contenidos que le gustan a un usuario');
END;

CREATE TRIGGER TR_users_BU
BEFORE UPDATE ON users
FOR EACH ROW
BEGIN
    RAISE_APPLICATION_ERROR(-20003,
    'No se puede actualizar un usuario');
END;

-- DisparadoresOK

INSERT INTO users (email, name)
    VALUES('user_name_1@gmail.com', 'user name');
INSERT INTO users (email, name)
    VALUES(NULL, 'user name');
INSERT INTO users (email, name)
    VALUES('user_name_3@gmail.com', 'user name');
UPDATE likes SET contents_id = 2;
DELETE FROM likes WHERE users_id = 1;
UPDATE users SET name = 'nombre prueba';

-- DisparadoresNoOk

-- Insertar el id y la fecha createdAT de un usuario,
-- esta se deber�a generar automaticamente 
INSERT INTO users
    VALUES(12, 'user_name_3@gmail.com', 'user name', '24/03/2022');
    
-- XDisparadores

DROP TRIGGER TR_users_BI;
DROP TRIGGER TR_likes_BDU;
DROP TRIGGER TR_users_BU;

-- Consultas

SELECT id, name AS Nombre, createdAT AS FechaCreacion, COUNT(id) AS Contenidos
    FROM likes JOIN users ON (users_id = id)
    WHERE id = 1
    GROUP BY id, name, createdAT;

-- CICLO 1: XPoblar

DELETE FROM posts;
DELETE FROM events;
DELETE FROM videos;
DELETE FROM likes;
DELETE FROM lables;
DELETE FROM stages;
DELETE FROM contents;
DELETE FROM subscriptions;
DELETE FROM exclusiveness;
DELETE FROM accounts;
DELETE FROM users;

-- CICLO 1: XTablas

DROP TABLE posts;
DROP TABLE events;
DROP TABLE videos;
DROP TABLE likes;
DROP TABLE lables;
DROP TABLE stages;
DROP TABLE contents;
DROP TABLE subscriptions;
DROP TABLE exclusiveness;
DROP TABLE accounts;
DROP TABLE users;

